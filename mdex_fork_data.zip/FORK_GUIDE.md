# mdex — Fork: NeoForge 1.21.1 + Standard Datapack + Modded Ores

## Overview

This fork extends `mdcdi1315/mdex` (branch `1.21.1`) with two additions:

1. **Standard datapack embedded** – the mining dimension ships with its own ore generation
   (vanilla ores + classic cave biomes) directly inside the JAR, so users don't need a
   separate datapack.
2. **Modded ores** – ores from **Modern Industrialization**, **Create**, and
   **Applied Energistics 2** are added conditionally via the mdex DCO system
   (`"modids"` field in `mdex:modded_ore`). If the mod isn't installed, the feature
   is silently skipped — no errors.

---

## Step 1 – Fork and checkout the right branch

```bash
# Fork on GitHub, then:
git clone https://github.com/YOUR_USERNAME/mdex.git
cd mdex
git checkout 1.21.1          # the existing 1.21.1 branch
git checkout -b feature/default-experience
```

---

## Step 2 – Gradle changes

### `gradle.properties` (patch from 1.20.1 values)

```diff
-minecraft_version = 1.20.1
-minecraft_versions = 1.20,1.20.1
-minecraft_version_range = [1.20,1.20.2)
-java_version = 17
-parchment_minecraft = 1.20.1
-parchment_version = 2023.09.03
-forge_version = 47.3.39
-forge_version_range = [47.3.0,)
-forge_loader_version_range = [47,)
-fabric_version = 0.92.3+1.20.1
-fabric_loader_version = 0.16.10
+minecraft_version = 1.21.1
+minecraft_versions = 1.21,1.21.1
+minecraft_version_range = [1.21,1.21.2)
+java_version = 21
+parchment_minecraft = 1.21.1
+parchment_version = 2024.11.17
+neoforge_version = 21.1.172
+neoforge_version_range = [21.1.0,)
+neoforge_loader_version_range = [4,)
```

> The 1.21.1 branch should already have these values.  
> Verify with `./gradlew --version` and `java -version` (must be Java 21).

### `repositories.gradle` – add new repos

```groovy
// Add inside the repositories {} block:
maven { url "https://maven.createmod.net" }          // Create mod
maven { url "https://maven.ithundxr.dev/snapshots" } // Registrate (Create dep)
maven { url "https://cursemaven.com" }               // CurseMaven (MI, AE2 fallback)
// AE2 is on Maven Central — already available by default
```

### `forge/build.gradle` – optional runtime dependencies

These mods are **data-only** dependencies (no Java API calls needed), so we only
need them at runtime for local testing. Do NOT mark them as required.

```groovy
dependencies {
    // Modern Industrialization — NeoForge 1.21.1 v2.3.11
    runtimeOnly "curse.maven:modern-industrialization-405388:6929325"

    // Create — NeoForge 1.21.1 v6.0.10
    runtimeOnly("com.simibubi.create:create-1.21.1:6.0.10-280:slim") {
        transitive = false
    }
    runtimeOnly "net.createmod.ponder:ponder-neoforge:1.0.82+mc1.21.1"
    runtimeOnly("dev.engine-room.flywheel:flywheel-neoforge-1.21.1:1.0.6") {
        transitive = false
    }
    runtimeOnly("com.tterrag.registrate:Registrate:MC1.21-1.3.0+67")

    // Applied Energistics 2 — NeoForge 1.21.1 v19.2.17
    runtimeOnly "org.appliedenergistics:appliedenergistics2:19.2.17"
}
```

> **Note:** If you need to call any Java API from these mods (not required for
> pure-data work), change `runtimeOnly` → `compileOnly` (and keep `runtimeOnly`
> for the test run).

---

## Step 3 – File structure

All data files live in:

```
forge/src/main/resources/data/
```

The files shipped with this guide use two namespaces:

| Namespace | Purpose |
|-----------|---------|
| `mdcdi1315_md` | Override the dimension definition and tag |
| `mdex_default_exp` | All features, placed features, biomes, and biome modifiers |
| `minecraft` | Tag overrides so vanilla ore features work on mining-dimension stone |

---

## Step 4 – Key technical notes

### The DCO system (`modids`)

Every `mdex:modded_ore` configured feature accepts:

```json
"config": {
  "modids": ["some_mod_id"],
  ...
}
```

If **any** mod in the list is not loaded, the feature is skipped entirely —
no crash, no log spam. For vanilla ores, use `"modids": []`.

### Stone tags used for ore targets

Use the mdex-provided block tags instead of vanilla stone tags, so ores can
replace the mining dimension's stone:

| Use as target | Tag |
|---------------|-----|
| Stone-layer ores | `#mdcdi1315_md:md_stone_blocks` |
| Deepslate-layer ores | `#mdcdi1315_md:md_deepslate_blocks` |
| Both | `#mdcdi1315_md:md_cave_stone_blocks` |

We also add these tags to vanilla's `#minecraft:stone_ore_replaceables` and
`#minecraft:deepslate_ore_replaceables` so the vanilla placed_features still
work inside the dimension.

### Biome modifier target

All ore features are injected into every mining-dimension biome via:

```json
"biomes": "#mdcdi1315_md:mining_dimension_biomes"
```

The fork registers its three biomes in that tag.

---

## Step 5 – Mod IDs reference

| Mod | Mod ID | Ores added |
|-----|--------|-----------|
| Modern Industrialization | `modern_industrialization` | antimony, bauxite, lignite_coal, monazite, salt, titanium, tungsten |
| Create | `create` | zinc |
| Applied Energistics 2 | `ae2` | certus_quartz |
